#ifndef WIKI_CPP
#define WIKI_CPP

#include "wiki.h"



Wiki::Wiki(string fileName)
{
    //FullGraph.csv size = 163380007
            adjList.resize(7000000);
            cin.open(fileName);
            cout << "Opening file: " << fileName << endl;
            if (cin.is_open())
            {
                string line;
                getline(cin, line); //ignore the top line since its just words
            }
            else
            {
                cout <<"invalid filename" << endl;
            }
}

#endif
