#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "wikiclass.cpp"
#include <string>
#include <chrono>
using namespace std::chrono;
using namespace std;

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    //initialize both graphs
    this->wiki = new Wiki(":/csv/900000_Cut.csv");
    wiki->run();

    //end wiki initialziation
    ui->setupUi(this);
    QCoreApplication::setApplicationName( QString("Wikipedia Associated Articles") );
    setWindowTitle( QCoreApplication::applicationName() );
    setWindowIcon(QIcon(":/images/icon.ico"));

}

MainWindow::~MainWindow()
{
    delete ui;
    delete wiki;
}

void MainWindow::on_startButton_clicked()
{
    ui->outList->clear();
    int from = std::stoi(ui->fromEdit->text().toStdString());
    int to = std::stoi(ui->fromEdit->text().toStdString());

    cout << "from: " << from << endl;
    cout << "to: " << to << endl;
    //convert strings to id

    vector<int> path;

    auto start = high_resolution_clock::now();
    //if adjList
    if (ui->rAdjList->isChecked()){
        path = wiki->listShortestDistance(wiki->adjList, from, to);
    }
    //if adjMatrix
    else{
        path = wiki->matrixShortestDistance(wiki->adjMatrix, from, to);
    }
    auto stop = high_resolution_clock::now();

    auto duration = duration_cast<microseconds>(stop - start);

    int pathSize = path.size();
    //display the number of pages required to reach the end
    ui->pgsNum->display(pathSize);
    //display the number of seconds required to find the shortest path
    double d = duration.count();
    ui->timeNum->display(d);

    //how to add things to the list


    for (unsigned int i =0; i < path.size(); i++){
        //convert it to text
        //fromStdString(string)
        string s = to_string(path[i]);
        ui->outList->addItem(QString::fromStdString(s));
    }
}

