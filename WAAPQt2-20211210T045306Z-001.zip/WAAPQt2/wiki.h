#ifndef WIKI_H
#define WIKI_H

#include <vector>
#include <unordered_map>
#include <string>
#include <iostream>
using namespace std;

class Wiki
{
public:
    vector<vector<int>> adjList;
    unordered_map<int, unordered_map<int, int>> adjMatrix;
    vector<pair<int, int>> edgeList;
    vector<string> path;

    Wiki(string fileName){}

    void run(){}

    void rewrite(){}

    void makePath(bool adjacencyList, int id_from, int id_to){}

    vector<string> getPath(){}

    ~Wiki(){}
private:
    ifstream cin;
    ofstream output;
    pair<int, int> parseLine(string line){}

    void makeEdges(){}

    void printNeighbors(vector<pair<int, int>> edgeList, int id){}

    bool listBFS(vector<vector<int>> &adjList, int src, int dest, vector<int> &pred){}

    vector<int> listShortestDistance(vector<vector<int>> adjList, int src, int dest){}

    bool matrixBFS(unordered_map<int, unordered_map<int, int>> &adjMatrix, int src, int dest, unordered_map<int, int> &pred){}

    vector<int> matrixShortestDistance(unordered_map<int, unordered_map<int, int>> adjMatrix, int src, int dest){}
    void printRaw(){}
    string search(){}

    string remover(string s, string remove){}

    vector<string> convertIdToName(vector<int> ids){}

};



#endif // WIKI_H
